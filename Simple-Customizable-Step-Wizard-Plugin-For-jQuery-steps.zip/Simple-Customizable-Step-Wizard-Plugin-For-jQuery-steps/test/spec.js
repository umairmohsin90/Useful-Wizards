describe('My Plugin', function () {

  it('version', function () {
    var ver = $.fn.steps.version;
    expect(ver).toEqual('1.0.2');
  });

});
